# memberships/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import CustomUserCreationForm  # Asegúrate de importar tu formulario personalizado

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'memberships/register.html', {'form': form})
# def register(request):
#     # Esta función maneja el registro de nuevos usuarios.
#     # Si el método de la solicitud es POST, intenta procesar y validar el formulario de creación de usuarios.
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             # Si el formulario es válido, guarda el nuevo usuario en la base de datos.
#             form.save()
#             # Después de guardar, redirecciona al usuario a la página de inicio de sesión.
#             return redirect('login')
#     else:
#         # Si el método no es POST (por ejemplo, GET), muestra un formulario de creación de usuario vacío.
#         form = UserCreationForm()
#     # Renderiza la página de registro con el formulario.
#     return render(request, 'memberships/register.html', {'form': form})

def login(request):
    # Esta función simplemente renderiza y devuelve la página de inicio de sesión.
    return render(request, 'memberships/login.html')

def profile(request):
    # Esta función renderiza y devuelve la página de perfil del usuario.
    return render(request, 'memberships/profile.html')
