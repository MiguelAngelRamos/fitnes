# memberships/models.py
from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    # Campo para almacenar detalles de salud del usuario. Es opcional y puede estar vacío.
    health_details = models.TextField(blank=True, null=True)

    # Campo para almacenar las actividades preferidas por el usuario. Se define como una cadena de texto
    # con una longitud máxima de 100 caracteres. Este campo es opcional y puede estar vacío.
    preferred_activities = models.CharField(max_length=100, blank=True, null=True)
